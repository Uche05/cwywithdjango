// Wait for the DOM to be ready

document.addEventListener("DOMContentLoaded", function () {
    // JavaScript to be fired on all pages

    //add extra js here
});